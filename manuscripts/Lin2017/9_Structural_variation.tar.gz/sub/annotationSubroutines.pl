#!/usr/bin/perl -w                                                                                                                                                                
use POSIX;
use strict;

#########################################
### Subroutines needed for the analysis of detected variants
###
#########################################

sub run_annovar {
    my ($input) = @_;
    my $annot_dir = "/proj/b2011141/nobackup/wabi/annotation/";
    my $bed     = "/proj/b2011141/nobackup/wabi/variants/".$input.".bed";
    my $annot   = "/proj/b2011141/nobackup/wabi/annotation/".$input.".avinput";
    
    open(B,$bed)          || die "Couldn't open $bed";
    open(A,">".$annot)    || die "Couldn't open $annot";
    
    while(my @line = split(/\t/, <B>)) {
	if ($line[0] !~/\#/ && $#line > 1) {
	    chomp $line[2];
	    my $pos = $line[0]."\t".$line[1]."\t".$line[2];
	    if ($bed =~/del/) { print A $pos."\t0\t-\n"; }
	    elsif ($bed =~/ins/) { print A $pos."\t0\t-\n"; }   
	}
    }                                                                                
    if ($input =~/tricho/ || $input=~/_t/) {
	my $db = $annot_dir."trichodb/";
	my $out = $annot_dir.$input;
	my $build = "tricho";
	system("annotate_variation.pl -out $out -build $build $annot $db --geneanno -dbtype refGene");
    }
    elsif ($input =~/tremula/) {
	my $db = $annot_dir."Potradb/";
	my $out = $annot_dir.$input;
	my $build = "Potra";
        system("annotate_variation.pl -out $out -build $build $annot $db --geneanno -dbtype refGene");
    }
    elsif ($input =~/tremuloides/) {
	my $db = $annot_dir."Potrsdb/";
        my $out = $annot_dir.$input;
        my $build = "Potrs";
        system("annotate_variation.pl -out $out -build $build $annot $db --geneanno -dbtype refGene");
    }
    
    my $variant = $annot_dir.$input.".variant_function";
    my $exonic = $annot_dir.$input.".exonic_variant_function";
    my $output = "/proj/b2011141/nobackup/wabi/stats/".$input."_annotion_stat.txt";
    my $bed_out = $annot_dir.$input.".variant_function_";

    open(V, $variant) || die "Couldn't open $variant";
    open(E, $exonic) || die "Couldn't open $exonic";
    open(O, ">".$output) || die "Couldn't open $output";
    
    print O "TYPE\tNUMBER\tFRACTION\tMEDIAN\tMEAN\tSTD\n";

    my %hash_type;
    my %hash_type_bed;
    my %hash_type_len;
    my %hash_gene;
    my %missing_gene;
    my $tot = 0;

    while(my @line =split(/\t/, <V>)) {
	$tot++;
	push(@{$hash_type_len{$line[0]}}, $line[4]-$line[3]);
	if (defined $hash_type{$line[0]}) { 
	    $hash_type{$line[0]}++;
	    $hash_type_bed{$line[0]} .= $line[2]."\t".$line[3]."\t".$line[4]."\n";
	}
	else {
	    $hash_type{$line[0]}=1; 
	    $hash_type_bed{$line[0]} = $line[2]."\t".$line[3]."\t".$line[4]."\n";
	}
	if($line[1] =~/\w+\d+g\d+/) { 
	    if (defined $hash_gene{$&}) { $hash_gene{$&}++;}
            else {$hash_gene{$&} = 1;}
	} 
	elsif($line[1] =~/\w+\:\d+/) { 
	    if (defined $hash_gene{$&}) { $hash_gene{$&}++;}
            else {$hash_gene{$&} = 1;}
	}
    }
    
    while(my @line =split(/\t/, <E>)) {
	if($line[2] =~/(\w+\d+g\d+)\.\d+\:wholegene/) { $missing_gene{$1}++;}
    }
    
    foreach my $key (keys %hash_type) {
	my @sorted = sort {$a <=> $b} @{$hash_type_len{$key}};
	my $median = $sorted[floor ($#sorted / 2)];
	my $av = av(@sorted);
	my $std = std(@sorted);
	print O $key."\t".$hash_type{$key}."\t".$hash_type{$key}/$tot."\t".$median."\t".$av."\t".$std."\n";
	my $bed = $bed_out.$key.".bed";
	open(B, ">".$bed) || die "Couldn't open $bed";
	print B $hash_type_bed{$key};
    }
    
    print O "\n\nMissing Genes:\n";
    foreach my $key (keys %missing_gene) {
	print O $key."\t".$missing_gene{$key}."\n";
    }
    
    print O "\n\nGenes with variants:\n";
    foreach my $key (keys %hash_gene) {
	print O $key."\t".$hash_gene{$key}."\n";
    }
}

sub filter_large {
    my ($file) = @_;
    my $tmp = "tmp_large.bed";
    open(F, $file) || die "Could't open $file";
    open(T, ">".$tmp) || die "Could't open $tmp";
    while (my $line =<F>) {
	my @line = split(/\t/, $line);
	if (($line[2] - $line[1]) < 10000000) {
	    print T $line;
	}  
    }
    rename $tmp, $file;
}

sub clean_bed {
    my ($in, $out) = @_;
    open(I, $in) || die "Couldn't open $in";
    open(O, ">".$out) || die"Couldn't open $out";
    while (my @line = split(/\t/, <I>)) {
	print O $line[0]."\t".$line[1]."\t".$line[2]."\n";
    }
}
sub assign_genotype {
    my $dir          = "/proj/b2011141/nobackup/wabi/results_tricho/";
    my $variants     = "/proj/b2011141/nobackup/wabi/variants/";
    my $sub_dir      = "/proj/b2011141/nobackup/wabi/results_tricho/sub/";
    my ($species, $inds, $var, $methods) = @_;
    my @inds         = @{$inds};
    my @methods      = @{$methods};
    my $geno_st100   = $variants.$species."_".$var."_all_st100.bed";
    my $geno_lt100   = $variants.$species."_".$var."_all_lt100.bed";
    my $a_geno_st100 = $variants.$species."_".$var."_assigned_geno_st100.bed";
    my $a_geno_lt100 = $variants.$species."_".$var."_assigned_geno_lt100.bed";
    my $t_geno_st100 = $variants.$species."_".$var."_assigned_trace_geno_st100.bed";
    my $t_geno_lt100 = $variants.$species."_".$var."_assigned_trace_geno_lt100.bed";
    my $a_geno       = $variants.$species."_".$var."_assigned_geno.bed";
    my $t_geno       = $variants.$species."_".$var."_assigned_trace_geno.bed";
    my $names        = join("\t", @inds);
    my $header       = $sub_dir."tmp_header";
    my $geno_st100_c = $dir.$species."_".$var."_geno_st100.bed_clean";
    my $geno_lt100_c = $dir.$species."_".$var."_geno_lt100.bed_clean";

    clean_bed($geno_st100, $geno_st100_c);
    clean_bed($geno_lt100, $geno_lt100_c);

    open(AST, ">".$a_geno_st100) || die "Couldn't open $a_geno_st100";
    open(ALT, ">".$a_geno_lt100) || die "Couldn't open $a_geno_lt100";
    open(TST, ">".$t_geno_st100) || die "Couldn't open $t_geno_st100";
    open(TLT, ">".$t_geno_lt100) || die "Couldn't open $t_geno_lt100";
    open(H, ">".$header)    || die "Couldn't open $header";

    print H "\#chr\tpos\tpos\t".$names."\n";
    
    my %st_overlap;
    my %lt_overlap;
    my %st_trace;
    my %lt_trace;
    
    unless (-s $a_geno_st100) {
        foreach my $ind (@inds) {
            my $ind_bed_st = $variants.$ind."_".$var."_merged_st100.bed";
            my $tmp_overlap_st = $sub_dir.$ind."_".$var."_merged_st100_tmp.bed";
            if (-e $geno_st100_c && -e $ind_bed_st) {
                system("intersectBed -a $geno_st100_c -b $ind_bed_st -r -f 0.5 -wao > $tmp_overlap_st");
            }
            else { rename $tmp_overlap_st, $geno_st100_c; }
            open(TOT, $tmp_overlap_st) || die "Couldn't open $tmp_overlap_st";
            while(my $line =<TOT>) {
                my @line = split(/\t/, $line);
                my $id = $line[0]."\t".$line[1]."\t".$line[2];
                unless (defined $st_overlap{$id}) { $st_overlap{$id} ='';}
                if (($#line > 3) && ($line[3] =~/\w+/)) { $st_overlap{$id} .="\t1"; }
                else { $st_overlap{$id} .="\t0"; }
            }
            system("rm $tmp_overlap_st");

            foreach my $method (@methods) {
                my $methods_bed = $sub_dir.$method."_".$ind."_".$var.".bed";
                my $tmp_overlap = $sub_dir.$method."_".$ind."_".$var.".bed_tmp";
                if (-e $geno_st100_c && -e $methods_bed) {
                    system("intersectBed -a $geno_st100_c -b $methods_bed -r -f 0.5 -wao > $tmp_overlap");
                }
                if (open(T, $tmp_overlap)) {
                    while(my $line =<T>) {
                        my @line = split(/\t/, $line);
                        my $id = $line[0]."\t".$line[1]."\t".$line[2];
                        if ($line[3] =~/\w+/) { $st_trace{$id}{$ind}{$method}= 1;}
                    }
                    system("rm $tmp_overlap");
                }
            }
        }

        foreach my $id (keys %st_overlap) {
            print AST $id.$st_overlap{$id}."\n";
        }
        foreach my $id (keys %st_trace) {
            print TST $id;
            foreach my $ind (@inds) {
                my $trace_value = 0;
                foreach my $method (keys %{$st_trace{$id}{$ind}}) {
                    if ((defined $st_trace{$id}{$ind}{$method}) && ( $st_trace{$id}{$ind}{$method} == 1)) { $trace_value = 1;}
                }
                print TST "\t".$trace_value;
            }
            print TST "\n";
        }
    }

    unless (-s $a_geno_lt100) {
        foreach my $ind (@inds) {
            my $ind_bed_lt = $variants.$ind."_".$var."_merged_lt100.bed";
            my $tmp_overlap_lt = $sub_dir.$ind."_".$var."_merged_lt100_tmp.bed";
	    if (-e $geno_lt100_c && -e $ind_bed_lt) {
		system("intersectBed -a $geno_lt100_c -b $ind_bed_lt -r -f 0.5 -wao > $tmp_overlap_lt");
            }
            else { rename $tmp_overlap_lt, $geno_lt100_c; }
            open(TOT, $tmp_overlap_lt) || die "Couldn't open $tmp_overlap_lt";
            while(my $line =<TOT>) {
		my @line = split(/\t/, $line);
                my $id = $line[0]."\t".$line[1]."\t".$line[2];
		unless (defined $lt_overlap{$id}) { $lt_overlap{$id} ='';}
                if (($#line > 3) && ($line[3] =~/\w+/)) { $lt_overlap{$id} .="\t1"; }
		else { $lt_overlap{$id} .="\t0"; }
            }
	    system("rm $tmp_overlap_lt");
	    
	    foreach my $method (@methods) {
		my $methods_bed = $sub_dir.$method."_".$ind."_".$var.".bed";
		my $tmp_overlap = $sub_dir.$method."_".$ind."_".$var.".bed_tmp";
		if (-e $geno_lt100_c && -e $methods_bed) {
		    system("intersectBed -a $geno_lt100_c -b $methods_bed -r -f 0.5 -wao > $tmp_overlap");
		}
		if (open(T, $tmp_overlap)) {
		    while(my $line =<T>) {
			my @line = split(/\t/, $line);
			my $id = $line[0]."\t".$line[1]."\t".$line[2];
			if ($line[3] =~/\w+/) { $lt_trace{$id}{$ind}{$method}= 1;}
		    }
		    system("rm $tmp_overlap");
		}
	    }
	}
    
	foreach my $id (keys %lt_overlap) {
	    print ALT $id.$lt_overlap{$id}."\n";
	}
	foreach my $id (keys %lt_trace) {
	    print TLT $id;
	    foreach my $ind (@inds) {
		my $trace_value = 0;
		foreach my $method (keys %{$lt_trace{$id}{$ind}}) {
		    if ((defined $lt_trace{$id}{$ind}{$method}) && ( $lt_trace{$id}{$ind}{$method} == 1)) { $trace_value = 1;}
		}
		print TLT "\t".$trace_value;
	    }
	    print TLT "\n";
	}
    }

    system("rm $geno_st100_c");
    system("rm $geno_lt100_c");
    
    system("sort -V -k1,1 -k2,2 -o $a_geno_st100 $a_geno_st100");
    system("sort -V -k1,1 -k2,2 -o $a_geno_lt100 $a_geno_lt100");
    system("sort -V -k1,1 -k2,2 -o $t_geno_st100 $t_geno_st100");
    system("sort -V -k1,1 -k2,2 -o $t_geno_lt100 $t_geno_lt100");
    
    system("cat $header $a_geno_st100 $a_geno_lt100 | sort -V -k1,1 -k2,2  > $a_geno");
    system("cat $header $t_geno_st100 $t_geno_lt100 | sort -V -k1,1 -k2,2  > $t_geno");
}

sub genotype {
    my $dir         = "/proj/b2011141/nobackup/wabi/results_tricho/";
    my $variants    = "/proj/b2011141/nobackup/wabi/variants/";
    my $sub_dir     = "/proj/b2011141/nobackup/wabi/results_tricho/sub/";
    my ($species, $inds, $var) = @_;
    my @inds        = @{$inds};
    my $merged_st100 = $variants.$species."_".$var."_merged_st100.bed";
    my $merged_lt100 = $variants.$species."_".$var."_merged_lt100.bed";
    my $geno_st100   = $variants.$species."_".$var."_geno_st100.bed";
    my $geno_lt100   = $variants.$species."_".$var."_geno_lt100.bed";
    my $geno         = $variants.$species."_".$var."_geno.bed";
    my $names        = join(' ', @inds);
    
    unless (-s $geno_st100) {
	my $input = '';
	foreach my $ind (@inds) {
            my $in_i = $variants.$ind."_".$var."_merged_st100.bed";
	    unless (-s $in_i) {
		open(I, ">".$in_i) || die "Coudln't open $in_i";
		print I "Chr01\t0\t1\n";
	    }
	    check_bed_file($in_i);
	    $input .= $in_i." ";
	}
	system("multiIntersectBed -i $input -names $names > $geno_st100");
    }
    unless (-s $geno_lt100) {
        my $input = '';
        foreach my $ind (@inds) {
            my $in_i = $variants.$ind."_".$var."_merged_lt100.bed";
	    unless (-s $in_i) {
		open(I, ">".$in_i) || die "Coudln't open $in_i";
		print I"Chr01\t0\t1\n";
	    }
	    $input .= $in_i." ";
            check_bed_file($in_i);
	}
	system("multiIntersectBed -i $input -names $names > $geno_lt100");
    }
    unless (-s $geno) {
	system("cat $geno_st100 $geno_lt100 | sort -V -k1,1 -k2,2  > $geno");
    }
}

sub find_indel_snp_cluster {
    my ($ind) = @_;
  
    my $ins_file  = "/proj/b2011141/nobackup/wabi/results_tricho/sub/".$ind."_ins_merged_st100.bed";
    my $del_file  = "/proj/b2011141/nobackup/wabi/results_tricho/sub/".$ind."_del_merged_st100.bed";
    my $snp_file  = "/proj/b2011141/nobackup/wabi/results_tricho/sub/".$ind."_snps.bed";
    my $out_ins_file  = "/proj/b2011141/nobackup/wabi/results_tricho/sub/".$ind."_ins_cluster.bed";
    my $out_del_file  = "/proj/b2011141/nobackup/wabi/results_tricho/sub/".$ind."_del_cluster.bed";
    my $rand          = int(rand(1000000));
    my $tmp1          = "tmp1_cluster.bed_".$rand;
    my $tmp2          = "tmp2_cluster.bed_".$rand;

    unless (-s $out_ins_file) {
	open(I, $ins_file)     || die "Couldn't open $ins_file";
	open(D, $del_file)     || die "Couldn't open $del_file";
	open(T, ">".$tmp1)     || die "Coudln't open $tmp1";
	open(OI, ">".$out_ins_file) || die "Coudln't open $out_ins_file";
	open(OD, ">".$out_del_file) || die "Coudln't open $out_del_file";
	
	my %ins_hash;
	my %del_hash;
	
	while (my @line = split(/\t/, <I>)) {
	    my $chr = $line[0];
	    my $lower = $line[1] - 10;
	    my $upper = $line[2] + 10;
	    print T $chr."\t".$lower."\t".$upper."\n";
	    $ins_hash{$chr."\t".$lower."\t".$upper} = '';
	}
	while (my @line = split(/\t/, <D>)) {
	    my $chr = $line[0];
	    my $lower = $line[1] - 10;
	    my $upper = $line[2] + 10;
	    print T $chr."\t".$lower."\t".$upper."\n";
	    $del_hash{$chr."\t".$lower."\t".$upper} = '';
	}
	my $b_string = $ins_file." ".$del_file." ".$snp_file;
	system("intersectBed -a $tmp1 -b $b_string -c > $tmp2");
	open(T2, $tmp2) || die "Couldn't open $tmp2";
	while (my $line = <T2>) {
	    my @line = split(/\t/, $line);
	    if ($line[3] > 6) {
		my $id = $line[0]."\t".$line[1]."\t".$line[2];
		if (defined $ins_hash{$id}) {
		    print OI $line;
		}
		elsif(defined $del_hash{$id}) {
		    print OD $line;
		}
	    }
	}
    }
}

sub unique {
    my ($in, $out) = @_;
    my $rand      = int(rand(1000000));
    my $tmp1      = "tmp1_unique.bed_".$rand;
    my $tmp2      = "tmp2_unique.bed_".$rand;
    open(I, $in) || die "Couldn't open $in";
    open(T, ">".$tmp1) || die "Couldn't open $tmp1";
    my %hash;
    while (my @line = split(/\t/,<I>)) {
	if ($#line > 1) {
	    chomp $line[2];
	    my $input = $line[0]."\t".$line[1]."\t".$line[2];
	    $hash{$input} = 1;
	}
    }
    foreach my $key (keys %hash) {
	print T $key."\n";
    }
    unique_start_ends($tmp1,$tmp2);
    system("sort -V -k1,1 -k2,2 $tmp2 > $out");
}

sub unique_start_ends {
    my ($in, $out) = @_;
    open(I, $in) || die "Couldn't open $in";
    open(O, ">".$out) || die "Couldn't open $out";

    my %start_hash;
    my %end_hash;
    my %out_hash;

    while (my $line =<I>) {
        my @line  = split(/\s+/, <I>);
        if ($#line > 1) { 
	    my $chr   = $line[0];
	    my $start = $line[1];
	    my $end   = $line[2];
	    push(@{$start_hash{$chr}{$start}}, $end); 
	    push(@{$end_hash{$chr}{$end}}, $start); 
	}
    }
    foreach my $chr (keys %start_hash) {
	foreach my $start (keys %{$start_hash{$chr}}) {
	    my @array;
	    foreach my $end (@{$start_hash{$chr}{$start}}) {
		push(@array, $end);
	    }
	    my @sorted = sort {$a <=> $b} @array;
	    my $end_median_pos = floor(int($#array / 2));
	    my $end_median = $sorted[$end_median_pos];
	    $out_hash{$chr}{$start} = $end_median;
	}
	foreach my $end (keys %{$end_hash{$chr}}) {
	    my @array;
	    foreach my $start (@{$end_hash{$chr}{$end}}) {
		push(@array, $start);
	    }
	    my @sorted = sort {$a <=> $b} @array;	
	    my $start_median_pos = floor(int($#array / 2));
	    my $start_median = $sorted[$start_median_pos];
	    for my $i (0 .. $#sorted) {
		unless ($i == $start_median_pos) {
		    delete $out_hash{$chr}{$sorted[$i]};
		}
	    }
	}
    }
    foreach my $chr (keys %out_hash) {
        foreach my $start (keys %{$out_hash{$chr}}) {
	    if ($out_hash{$chr}{$start} > $start) {
		print O $chr."\t".$start."\t".$out_hash{$chr}{$start}."\n";
	    }
	    else {
		print O $chr."\t".$out_hash{$chr}{$start}."\t".$start."\n";
	    }
	}
    }
}

sub merge_ind {
    my $variants       = "/proj/b2011141/nobackup/wabi/variants/"; 
    my $dir            = "/proj/b2011141/nobackup/wabi/results_tricho/";
    my $sub_dir        = "/proj/b2011141/nobackup/wabi/results_tricho/sub/";
    my $annot_dir      = "/proj/b2011141/nobackup/wabi/annot/";
    my ($ind, $var, $methods, $limit) = @_;
    my @methods        = @{$methods};
    my $tot            = $sub_dir.$ind."_".$var."_tot.bed";
    my $unique_lt100   = $sub_dir.$ind."_".$var."_unique_lt100.bed";
    my $unique_st100   = $sub_dir.$ind."_".$var."_unique_st100.bed";
    my $merged         = $variants.$ind."_".$var."_merged.bed";
    my $unmerged_lt100 = $sub_dir.$ind."_".$var."_unmerged_lt100.bed";
    my $unmerged_st100 = $sub_dir.$ind."_".$var."_unmerged_st100.bed";
    my $merged_lt100   = $variants.$ind."_".$var."_merged_lt100.bed";
    my $merged_st100   = $variants.$ind."_".$var."_merged_st100.bed";
    my $rand           = int(rand(1000000));
    my $tmp            = "tmp1.bed_".$ind."_".$rand;
    my $tmp_st100      = "tmp_st100_".$ind."_".$var."_".$rand;
    my $tmp_lt100      = "tmp_lt100_".$ind."_".$var."_".$rand;
  
    unless (-s $tot) {
        unless(-e $tot) { system("touch $tot");}
        for (my $i = 0; $i <= $#methods; $i++) {
            for (my $j = 0; $j <= $#methods; $j++) {
		unless ($i == $j) {
		    my $in_i = $sub_dir.$methods[$i]."_".$ind."_".$var.".bed";
		    my $in_j = $sub_dir.$methods[$j]."_".$ind."_".$var.".bed";
		    if ((-s $in_i) && (-s $in_j)) {
			filter_large($in_i);
			filter_large($in_j);
			system("intersectBed -a $in_i -b $in_j -r -f $limit >> $tot");
		    }
		}
	    }
	}
    }
    unless (-s $unmerged_st100) {
	filter_lt100($tot, $tmp_lt100, $tmp_st100);
	unique($tmp_st100, $unmerged_st100);
        unique($tmp_lt100, $unmerged_lt100);
    }
}

sub merge_species {
    my $dir         = "/proj/b2011141/nobackup/wabi/results_tricho/";
    my $sub_dir     = "/proj/b2011141/nobackup/wabi/results_tricho/sub/";
    my $annot_dir   = "/proj/b2011141/nobackup/wabi/annot/";
    my $variants    = "/proj/b2011141/nobackup/wabi/variants/";
    my ($species, $inds, $var, $limit) = @_;
    my @inds               = @{$inds};
    my $rand               = int(rand(1000000));
    my $tot                = $sub_dir.$species."_".$var."_tot.bed";
    my $all_unmerged       = $sub_dir.$species."_".$var."_all_unmerged.bed";
    my $all_unmerged_lt100 = $sub_dir.$species."_".$var."_all_unmerged_lt100.bed";
    my $all_unmerged_st100 = $sub_dir.$species."_".$var."_all_unmerged_st100.bed";
    my $all                = $variants.$species."_".$var."_all.bed";
    my $all_lt100          = $variants.$species."_".$var."_all_lt100.bed";
    my $all_st100          = $variants.$species."_".$var."_all_st100.bed";
    my $unique             = $sub_dir.$species."_".$var."_unique.bed";
    my $merged             = $variants.$species."_".$var."_merged.bed";
    my $unmerged_lt100     = $sub_dir.$species."_".$var."_unmerged_lt100.bed";
    my $unmerged_st100     = $sub_dir.$species."_".$var."_unmerged_st100.bed";
    my $merged_lt100       = $variants.$species."_".$var."_merged_lt100.bed";
    my $merged_st100       = $variants.$species."_".$var."_merged_st100.bed";
    my $tmp_lt100          = "tmp_species_lt100.bed_".$species."_".$rand;
    my $tmp_st100          = "tmp_species_st100.bed_".$species."_".$rand;
    my $tmp                = "tmp_species.bed_".$species."_".$rand;
    unless (-s $all_unmerged && -s $tot) {
        unless(-e $tot){ system("touch $tot");}
        unless(-e $all_unmerged){ system("touch $all_unmerged");}
        for (my $i = 0; $i <= $#inds; $i++) {
	    my $in_i = $variants.$inds[$i]."_".$var."_merged.bed";
	    system("cat $in_i >> $all_unmerged");
            for (my $j = 0; $j <= $#inds; $j++) {		
		unless ($i == $j) {
		    my $in_j = $variants.$inds[$j]."_".$var."_merged.bed";
		    if (-s $in_i && -s $in_j) {
			system("intersectBed -a $in_i -b $in_j -r -f $limit >> $tot");
		    }
		}
	    }
	}
    }
    unless (-s $unmerged_lt100) {
	filter_lt100($tot, $tmp_lt100, $tmp_st100);
        unique($tmp_st100, $unmerged_st100);
        unique($tmp_lt100, $unmerged_lt100);
    }
    unless (-s $all_unmerged_lt100) {
	filter_lt100($all_unmerged, $tmp_lt100, $tmp_st100);
        unique($tmp_st100, $all_unmerged_st100);
        unique($tmp_lt100, $all_unmerged_lt100);
    }
    
    check_bed_file($unmerged_st100);
    check_bed_file($unmerged_lt100);
    check_bed_file($all_unmerged_st100);
    check_bed_file($all_unmerged_lt100);

    unless (-s $all_lt100) {
        merge_var($all_unmerged_lt100, $all_lt100, $limit);
    }
    unless (-s $all_st100) {
        system("mergeBed -i $all_unmerged_st100 > $all_st100");
    }
    unless (-s $all){
        system("cat $all_lt100 $all_st100 | sortBed -i stdin > $all");
    }
    unless (-s $merged_lt100) {
	merge_var($unmerged_lt100, $merged_lt100, $limit);
    }
    unless (-s $merged_st100) {
	system("mergeBed -i $unmerged_st100 > $merged_st100");
    }    
    unless (-s $merged) {
	system("cat $merged_lt100 $merged_st100 | sortBed -i stdin > $merged");
    }
}

sub filter_lt100 {
    my $in  = $_[0];
    my $out1 = $_[1];
    my $out2 = $_[2];
    open(I, $in)        || die "Couldn't open $in";
    open(O1, ">".$out1) || die "Couldn't open $out1";
    open(O2, ">".$out2) || die "Couldn't open $out2";
    while(my $line =<I>) {
	my @line = split(/\t/, $line);
	if ($line[2] - $line[1] > 200) {
	    print O1 $line;
	}
	else { print O2 $line;	}
    }
}

sub check_bed_file {
    my ($in) = @_;
    my $tmp  = $in."_checked";
    open(F, $in) || die "Couldn't open $in";
    open(T, ">".$tmp) || die "Couldn't open $tmp";
    while(my @line = split(/\t/, <F>)) {
	if ($#line > 1) {
	    chomp $line[2];
	    if ($line[2] > $line[1]) {	print T $line[0]."\t".$line[1]."\t".$line[2]."\n";    }
	    else { print T $line[0]."\t".$line[2]."\t".$line[1]."\n";   }
	}
    }
    system("sort -V -k1,1 -k2,2 $tmp > $in");
    system("rm $tmp");
}

sub extract_stat_file {
    my $stat_dir         = "/proj/b2011141/nobackup/wabi/stats/";
    my $variants         = "/proj/b2011141/nobackup/wabi/variants/".$_[0];
    my $stat             = $stat_dir."stat_".$_[0];
    my $box              = $stat_dir."box_".$_[0];

    unless (-s $stat) {
        open(BOX, ">".$box)   || die "Couldn't open $box";
	open(STAT, ">".$stat) || die "Couldn't open $stat";
	
	my @array;
	my $sum = 0;

        if (open(S, $variants)) {
            while (my @line =split(/\s+/,<S>)) {
                my $len = $line[2] - $line[1] + 1;
                $sum += $len;
                push(@array, $len);
            }
        }
        my @sorted_array = sort {$a <=> $b} @array;
	my $number_of_variants = $#array + 1;
        my $mean = 0; if ($number_of_variants > 0)   { $mean = $sum / $number_of_variants; }
        my $median = 0; if ($number_of_variants > 0) { $median = $sorted_array[floor($number_of_variants/2)]; }
        my $max = $sorted_array[$#sorted_array];
	my $min = $sorted_array[0];

        print STAT "\#number_of_variants\tmean\tmedian\tmax\tmin\n";
        print STAT $number_of_variants."\t".$mean."\t".$median."\t".$max."\t".$min."\n";
	print BOX "SIZE\n";

        foreach my $var (@sorted_array ) {
            print BOX $var."\n";
        }
    }
}

sub extract_stat {
    my $stat_dir         = "/proj/b2011141/nobackup/wabi/stats/";
    my $variants         = "/proj/b2011141/nobackup/wabi/variants/";
    my ($species, $inds, $var) = @_;
    my @inds             = @{$inds};
    my $stat             = $stat_dir."stat_".$species."_".$var.".txt";
    my $box              = $stat_dir."box_lt_".$species."_".$var.".txt";
    
    unless (-s $stat) {
        open(BOX, ">".$box)   || die "Couldn't open $box";
	open(STAT, ">".$stat) || die "Couldn't open $stat";
        my $species_var      = $variants.$species."_".$var."_all.bed";
        my @species_array;
        my $species_sum = 0;
	
        if (open(S, $species_var)) {
	    while (my @line =split(/\t/,<S>)) {
		my $len = $line[2] - $line[1] + 1;
		$species_sum += $len;
		push(@species_array, $len);
	    }
	}
        my @sorted_species_array = sort {$a <=> $b} @species_array;
        my $number_of_variants = $#species_array + 1;
        my $mean = 0; if ($number_of_variants > 0)   { $mean = $species_sum / $number_of_variants; }
        my $median = 0; if ($number_of_variants > 0) { $median = $sorted_species_array[floor($number_of_variants/2)]; }
        my $max = $sorted_species_array[$#sorted_species_array];
        my $min = $sorted_species_array[0]; 
	
	print STAT "\#species\tnumber_of_variants\tmean\tmedian\tmax\tmin\n";
        print STAT $species."\t".$number_of_variants."\t".$mean."\t".$median."\t".$max."\t".$min."\n";
	print BOX "SIZE\n";
	
	foreach my $var (@sorted_species_array ) {
	    print BOX $var."\n";
        }
	
        foreach my $ind (@inds) {
            my $var     = $variants.$ind."_".$var."_merged.bed";
            my $ind_sum = 0;
            my @ind_array;
	    my $number_of_ind_variants = 0;
	    my $mean_ind = 0; my $median_ind = 0; my $max_ind = 0; my $min_ind = 0;
            if (open(V, $var)) {
		while (my @line =split(/\t/,<V>)) {
		    my $len = $line[2] - $line[1] + 1;
		    $ind_sum += $len;
		    push(@ind_array, $len);
		}
		my @sorted_ind_array = sort {$a <=> $b} @ind_array;
		$number_of_ind_variants = $#ind_array + 1;
		$mean_ind         = 0; if ($number_of_ind_variants > 0)  { $mean_ind = $ind_sum / $number_of_ind_variants; }
		$median_ind       = 0; if ($number_of_ind_variants > 0)  { $median_ind = $sorted_ind_array[floor($number_of_ind_variants/2)]; }
		$max_ind          = $sorted_ind_array[$#sorted_ind_array];
		$min_ind          = $sorted_ind_array[0];
	    }
            print STAT $ind."\t".$number_of_ind_variants."\t".$mean_ind."\t".$median_ind."\t".$max_ind."\t".$min_ind."\n";
        }
    }
}

sub merge_var {
    my ($in, $out, $limit) = @_;
    my $rand      = int(rand(1000000));
    my $tmp       = "tmp_merge_".$rand.".bed";
    open(I, $in)      || die "Couldn't open $in";
    open(T, ">".$tmp) || die "Couldn't open $tmp";
    my $present_chr = "tmp";
    my %prim_hash;
    my $id = 0;

    while (my $line = <I>) {
	chomp $line;
	my @line = split(/\t/, $line);
	my $chr = "tmp2";
	if (defined $line[0]) { $chr = $line[0]; }
	if ($chr ne $present_chr) {
	   # print "Merge:\t".$chr."\n";
	    my %comp_hash;
	    foreach my $key_1 ( keys %prim_hash) {
		foreach my $key_2 (keys %prim_hash) {
		    unless ($key_1 eq $key_2) {
                        my @entry = split(/\t/, $prim_hash{$key_1});
			my @entry_comp = split(/\t/, $prim_hash{$key_2});
			if (overlap($entry[1], $entry[2], $entry_comp[1], $entry_comp[2], $limit) == 1) {
			    push(@{$comp_hash{$key_1}}, $key_2);
			}
		    }
		} 		  
	    }
	    my @keys_comp_hash = keys %comp_hash;
	    while (@keys_comp_hash) {
		my $key = shift (@keys_comp_hash);
		if (defined $comp_hash{$key}) {
		    my @common_array;
		    push(@common_array, $key);
		    foreach my $number (@{$comp_hash{$key}}) {
			push(@common_array, $number);
			foreach my $related_number (@{$comp_hash{$number}}) {
			    push(@common_array, $related_number);
			    delete $comp_hash{$related_number};
			}
			delete $comp_hash{$number};
		    }
		    my @starts; my @ends;
		    my %hash   = map { $_, 1 } @common_array;
		    my @unique = keys %hash;
		    foreach my $elem (@unique) {
			if (defined $prim_hash{$elem}) {
			    my @elem = split(/\t/, $prim_hash{$elem});
			    push(@starts, $elem[1]);
			    push(@ends, $elem[2]);
			    delete $prim_hash{$elem};
			}
		    }
		    my $start = av(@starts);
		    my $end   = av(@ends);
		    print T $present_chr."\t".$start."\t".$end."\n";
		}
		delete $comp_hash{$key};
		@keys_comp_hash = keys %comp_hash;
	    }
	    foreach my $key (keys %prim_hash) {
		print T $prim_hash{$key}."\n";
		delete $prim_hash{$key};
	    }
	    $present_chr = $chr;
	    $id = 0;
	}
	else {
	    $prim_hash{$id} = $line;
	    $id++;
	}
    }
    my %comp_hash;
    foreach my $key_1 ( keys %prim_hash) {
	foreach my $key_2 (keys %prim_hash) {
	    unless ($key_1 eq $key_2) {
		if ((defined $prim_hash{$key_1}) && (defined $prim_hash{$key_2})) {
		    my @entry = split(/\t/, $prim_hash{$key_1});
		    my @entry_comp = split(/\t/, $prim_hash{$key_2});
		    if ($#entry > 1 && $#entry_comp > 1) {
			if (overlap($entry[1], $entry[2], $entry_comp[1], $entry_comp[2], $limit) == 1) {
			    push(@{$comp_hash{$key_1}}, $key_2);
			}
		    }
		}
	    }
	}
    }
    my @keys_comp_hash = keys %comp_hash;
    while (@keys_comp_hash) {
	my $key = shift (@keys_comp_hash);
	if (defined $comp_hash{$key}) {
	    my @common_array;
	    push(@common_array, $key);
	    foreach my $number (@{$comp_hash{$key}}) {
		push(@common_array, $number);
		foreach my $related_number (@{$comp_hash{$number}}) {
		    push(@common_array, $related_number);
		    delete $comp_hash{$related_number};
		}
		delete $comp_hash{$number};
	    }
	    my @starts; my @ends;
	    my %hash   = map { $_, 1 } @common_array;
	    my @unique = keys %hash;
	    foreach my $elem (@unique) {
		if (defined $prim_hash{$elem}) {
		    my @elem = split(/\t/, $prim_hash{$elem});
		    push(@starts, $elem[1]);
		    push(@ends, $elem[2]);
		    delete $prim_hash{$elem};
		}
	    }
	    my $start = av(@starts);
	    my $end   = av(@ends);
	    print T $present_chr."\t".$start."\t".$end."\n";
	}
	delete $comp_hash{$key};
	@keys_comp_hash = keys %comp_hash;
    }
    foreach my $key (keys %prim_hash) {
	print T $prim_hash{$key}."\n";
	delete $prim_hash{$key};
    }
    check_bed_file($tmp);
    system("sort -V -k1,1 -k2,2 $tmp > $out");
}

sub overlap {
    my ($start_1, $end_1, $start_2, $end_2, $limit) = @_;
    my $len_1 = $end_1 - $start_1;
    my $len_2 = $end_2 - $start_2;
    my $start = max($start_1, $start_2);
    my $end   = min($end_1, $end_2);
    if (($len_1 > 0) && ($len_2 > 0)) {
	if ((($end - $start) / $len_1 > $limit) && (($end - $start) / $len_2 > $limit)) {
	    return 1;
	}
    }
    else {return 0;}
}

sub av {
    my @array   = @_;

    my $sum = 0;
    my $nr  = 0;
    foreach my $e (@array) {
	$sum += $e;
	$nr++;
    }
    return(ceil($sum / $nr));
}

sub max {
    my ($in1, $in2) = @_;
    if ($in1 >= $in2) {
	return $in1;
    }
    else { return $in2;}
}

sub min {
    my ($in1, $in2) = @_;
    if ($in1 <= $in2) {
	return $in1;
    }
    else { return $in2;}
}

sub std {
    my @data = @_;
    my $av = av(@data);
    my $sqtotal = 0;
    foreach(@data) {
	$sqtotal += ($av-$_) ** 2;
    }
    my $std = ($sqtotal / ($#data-1)) ** 0.5;
    return $std;
}

1;
