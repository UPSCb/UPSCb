#!/usr/bin/perl -w
use POSIX;
use strict;

########################
### Script that takes as input variants detected by a number of different algorithms, 
### process these and outputs reliable sets of variants for each individual and each species
###
########################

require '/proj/b2011141/nobackup/wabi/pl/annotationSubroutines.pl';

my $limit = 0.5;
my $dir       = "/proj/b2011141/nobackup/wabi/results_tricho/";
my $stats     = "/proj/b2011141/nobackup/wabi/stats/";
my $variants  = "/proj/b2011141/nobackup/wabi/variants/";
my $sub_dir   = "/proj/b2011141/nobackup/wabi/results_tricho/sub/";
my $annot_dir = "/proj/b2011141/nobackup/wabi/annot/";
my $tmp       = "tmp.txt";

my @tremula_t      = ("tremula_t_SwAsp001","tremula_t_SwAsp009","tremula_t_SwAsp011","tremula_t_SwAsp014","tremula_t_SwAsp021","tremula_t_SwAsp025","tremula_t_SwAsp032","tremula_t_SwAsp033","tremula_t_SwAsp045","tremula_t_SwAsp047","tremula_t_SwAsp055","tremula_t_SwAsp057","tremula_t_SwAsp067","tremula_t_SwAsp068","tremula_t_SwAsp076","tremula_t_SwAsp078","tremula_t_SwAsp087","tremula_t_SwAsp088","tremula_t_SwAsp096","tremula_t_SwAsp098","tremula_t_SwAsp103","tremula_t_SwAsp110","tremula_t_SwAsp111","tremula_t_SwAsp114");
my @tremula_sub   = ("tremula_t_SwAsp001","tremula_t_SwAsp009","tremula_t_SwAsp011","tremula_t_SwAsp014","tremula_t_SwAsp021","tremula_t_SwAsp025","tremula_t_SwAsp032","tremula_t_SwAsp033","tremula_t_SwAsp045","tremula_t_SwAsp047","tremula_t_SwAsp055","tremula_t_SwAsp057","tremula_t_SwAsp067","tremula_t_SwAsp068","tremula_t_SwAsp076","tremula_t_SwAsp078","tremula_t_SwAsp087","tremula_t_SwAsp088","tremula_t_SwAsp096","tremula_t_SwAsp098","tremula_t_SwAsp103","tremula_t_SwAsp110","tremula_t_SwAsp111","tremula_t_SwAsp114");
my @tremula       = ("tremula_SwAsp001","tremula_SwAsp009","tremula_SwAsp011","tremula_SwAsp014","tremula_SwAsp021","tremula_SwAsp025","tremula_SwAsp032","tremula_SwAsp033","tremula_SwAsp045","tremula_SwAsp047","tremula_SwAsp055","tremula_SwAsp057","tremula_SwAsp067","tremula_SwAsp068","tremula_SwAsp076","tremula_SwAsp078","tremula_SwAsp087","tremula_SwAsp088","tremula_SwAsp096","tremula_SwAsp098","tremula_SwAsp103","tremula_SwAsp110","tremula_SwAsp111","tremula_SwAsp114" ,"tremula_SwAsp003","tremula_SwAsp004","tremula_SwAsp005","tremula_SwAsp010","tremula_SwAsp012","tremula_SwAsp013","tremula_SwAsp015","tremula_SwAsp016","tremula_SwAsp018","tremula_SwAsp022","tremula_SwAsp023","tremula_SwAsp024","tremula_SwAsp026","tremula_SwAsp028","tremula_SwAsp029","tremula_SwAsp030","tremula_SwAsp034","tremula_SwAsp035","tremula_SwAsp036","tremula_SwAsp037","tremula_SwAsp038","tremula_SwAsp039","tremula_SwAsp040","tremula_SwAsp041","tremula_SwAsp042","tremula_SwAsp043","tremula_SwAsp044","tremula_SwAsp046","tremula_SwAsp049","tremula_SwAsp050","tremula_SwAsp051","tremula_SwAsp052","tremula_SwAsp054","tremula_SwAsp056","tremula_SwAsp058","tremula_SwAsp059","tremula_SwAsp060","tremula_SwAsp061","tremula_SwAsp062","tremula_SwAsp063","tremula_SwAsp064","tremula_SwAsp065","tremula_SwAsp066","tremula_SwAsp069","tremula_SwAsp070","tremula_SwAsp071","tremula_SwAsp072","tremula_SwAsp073","tremula_SwAsp074","tremula_SwAsp077","tremula_SwAsp079","tremula_SwAsp080","tremula_SwAsp081","tremula_SwAsp082","tremula_SwAsp084","tremula_SwAsp086","tremula_SwAsp089","tremula_SwAsp090","tremula_SwAsp091","tremula_SwAsp092","tremula_SwAsp093","tremula_SwAsp094","tremula_SwAsp095","tremula_SwAsp097","tremula_SwAsp106","tremula_SwAsp109","tremula_SwAsp112","tremula_SwAsp113","tremula_SwAsp115","tremula_SwAsp116");
my @tremuloides_t  = ("tremuloides_t_Dan1","tremuloides_t_Dan2","tremuloides_t_PG1","tremuloides_t_PG2","tremuloides_t_PI3","tremuloides_t_Sau1","tremuloides_t_Sau2","tremuloides_t_Wau1","tremuloides_t_Alb10","tremuloides_t_Alb17","tremuloides_t_Alb18","tremuloides_t_Alb25","tremuloides_t_Alb31","tremuloides_t_Alb33","tremuloides_t_Alb35","tremuloides_t_Albb15");
my @tremuloides  = ("tremuloides_Dan1","tremuloides_Dan2","tremuloides_PG1","tremuloides_PG2","tremuloides_PI3","tremuloides_Sau1","tremuloides_Sau2","tremuloides_Wau1","tremuloides_Alb10","tremuloides_Alb17","tremuloides_Alb18","tremuloides_Alb25","tremuloides_Alb31","tremuloides_Alb33","tremuloides_Alb35","tremuloides_Albb15");
my @trichocharpa = ("trichocharpa_SRR15695_19_20","trichocharpa_SRR1569629","trichocharpa_SRR15697_62_63","trichocharpa_SRR1569781","trichocharpa_SRR1569814","trichocharpa_SRR1570189","trichocharpa_SRR1570762","trichocharpa_SRR1571016","trichocharpa_SRR1571038","trichocharpa_SRR1571152","trichocharpa_SRR1571215","trichocharpa_SRR1571263","trichocharpa_SRR1571274","trichocharpa_SRR1571343","trichocharpa_SRR1571362","trichocharpa_SRR1571397","trichocharpa_SRR1571416","trichocharpa_SRR1571432","trichocharpa_SRR1571497","trichocharpa_SRR1571500","trichocharpa_SRR1571518","trichocharpa_SRR1571532","trichocharpa_SRR1571572");
my @inds         = (@tremula_sub, @tremula,@trichocharpa, @tremula_t, @tremuloides_t, @tremuloides);
my @vars         = ("del","ins", "inv");
my @species      = ("tremula_sub", "trichocharpa","tremula_t", "tremuloides_t","tremuloides", "tremula");
my @methods      = ("samtools", "varscan", "freec", "breakdancer", "delly", "coverage_1kb", "gatk", "lumpy");

my @table_input;

foreach my $var (@vars) {
    foreach my $ind (@inds) {
        print "merge ind: $ind, $var\n";
	my $merged    = $variants.$ind."_".$var."_merged.bed";
        my $merged_f  = $variants.$ind."_".$var."_merged_filtered.bed";
	my $unmerged_lt100  = $sub_dir.$ind."_".$var."_unmerged_lt100.bed";
	my $unmerged_st100  = $sub_dir.$ind."_".$var."_unmerged_st100.bed";
	my $merged_lt100  = $variants.$ind."_".$var."_merged_lt100.bed";
	my $merged_st100  = $variants.$ind."_".$var."_merged_st100.bed";
	my $merged_lt100_f  = $variants.$ind."_".$var."_merged_lt100_filtered.bed";
        my $merged_st100_f  = $variants.$ind."_".$var."_merged_st100_filtered.bed";
	merge_ind($ind, $var, \@methods, $limit);
	unless (-s $merged && -s $unmerged_lt100 && -s $merged_lt100) {
	    merge_var($unmerged_lt100, $merged_lt100, $limit);
	    system("mergeBed -i $unmerged_st100 > $merged_st100"); 
	    system("cat $merged_lt100 $merged_st100 | sortBed -i stdin > $merged");
	}
	filter_large($merged_lt100);
	filter_large($merged_st100);
	filter_large($merged);
   }
    
    for (my $i = 0; $i <= $#species; $i++) {
	print "merge species: $species[$i] $var\n";
	my $merged         = $variants.$species[$i]."_".$var."_merged.bed";
	my $all            = $variants.$species[$i]."_".$var."_all.bed";
	my $merged_f       = $variants.$species[$i]."_".$var."_merged_filtered.bed";
        my $all_f          = $variants.$species[$i]."_".$var."_all_filtered.bed";
	my $merged_lt100   = $variants.$species[$i]."_".$var."_merged_lt100.bed";
	my $merged_st100   = $variants.$species[$i]."_".$var."_merged_st100.bed";
	my $merged_lt100_f = $variants.$species[$i]."_".$var."_merged_lt100_filtered.bed";
        my $merged_st100_f = $variants.$species[$i]."_".$var."_merged_st100_filtered.bed";
	my $all_lt100   = $variants.$species[$i]."_".$var."_all_lt100.bed";
        my $all_st100   = $variants.$species[$i]."_".$var."_all_st100.bed";
        my $all_lt100_f = $variants.$species[$i]."_".$var."_all_lt100_filtered.bed";
        my $all_st100_f = $variants.$species[$i]."_".$var."_all_st100_filtered.bed";
	
        unless (-s $merged && -s $all) {
	    if ($species[$i] =~/trichocharpa/) {
		merge_species($species[$i], \@trichocharpa, $var, $limit);
	    }
	    elsif ($species[$i] =~/tremula_t/) {
		merge_species($species[$i], \@tremula_t, $var, $limit);
	    }
	    elsif ($species[$i] =~/tremuloides_t/) {
		merge_species($species[$i], \@tremuloides_t, $var, $limit);
	    }
	    elsif ($species[$i] =~/tremula/) {
		merge_species($species[$i], \@tremula, $var, $limit);
	    }
	    elsif ($species[$i] =~/tremuloides/) {
		merge_species($species[$i], \@tremuloides, $var, $limit);
	    }
            filter_large($merged);
            filter_large($all_lt100);
            filter_large($all);
	}
	my $input = $species[$i]."_".$var."_all";
	run_annovar($input);
	
	my $input_st100 = $species[$i]."_".$var."_all_st100";
        run_annovar($input_st100);
    }
    extract_stat('trichocharpa', \@trichocharpa, $var);
    extract_stat('tremula', \@tremula, $var);
    extract_stat('tremula_t', \@tremula_t, $var);
    extract_stat('tremuloides', \@tremuloides, $var);
    extract_stat('tremuloides_t', \@tremuloides_t, $var);
    
    genotype('trichocharpa', \@trichocharpa, $var);
    genotype('tremula', \@tremula, $var);
    genotype('tremula_t', \@tremula_t, $var);
    genotype('tremuloides', \@tremuloides, $var);
    genotype('tremuloides_t', \@tremuloides_t, $var);

    genotype('tremula_sub', \@tremula_sub, $var);   

    assign_genotype('trichocharpa', \@trichocharpa, $var, \@methods);
    assign_genotype('tremula', \@tremula, $var, \@methods);
    assign_genotype('tremula_t', \@tremula_t, $var, \@methods);
    assign_genotype('tremuloides', \@tremuloides, $var, \@methods);
    assign_genotype('tremuloides_t', \@tremuloides_t, $var,\@methods);

    assign_genotype('tremula_sub', \@tremula_sub, $var, \@methods);

}

my $table    = $stats."table_vars.txt";

open(T, ">".$table) || die "Couldn't open $table";
print T "var\tspecies\tname\tnumber of var\tmean\tmedian\tmax\tmin\n";

foreach my $species (@species) {
    foreach my $var (@vars) {
	my $file = $stats."stat_".$species."_".$var.".txt";
        open(F, $file) || die "Couldn't open $file";
        while(my $line =<F>) {
            print T $var."\t".$species."\t".$line;
        }
        my $file_lt10 = $stats."stat_lt100_".$species."_".$var.".txt";
        open(FLT10, $file_lt10) || die "Couldn't open $file_lt10";
        while(my $line =<FLT10>) {
            print T $var."_lt100\t".$species."\t".$line;
        }
    }
}

